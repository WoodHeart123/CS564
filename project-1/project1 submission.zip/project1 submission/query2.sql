SELECT COUNT(*) 
FROM User 
WHERE Location = 'New York';

/*我的 DBMS 报错如果String用double quotes，确认下是双的还是单的quote？*/

/*
SELECT COUNT(*) 
FROM User 
WHERE LOCATION = "New York";
*/